﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStatus : CharaStatus {
    /*playerstatus exp;
    playerstatus Lv;
    playerstatus Action;*/

    //Playerstatus playerstatus = new Playerstatus();

    
    
        
    //キャラが未行動の時true
    //キャラが行動済みの時false

    //Playerstatus()
    //{
    //    this.Exp = 0;
    //    Lv = 1;
    //    ActionFlag = true;//取り敢えず無視

    //}

    

    // Use this for initialization
    void Start () {
        //StartSetting();

       //Exp = 0;
       //Lv = 1;






       
	}

    // Update is called once per frame
    void Update() {

        
    }
    
    
}

    //public void FlagChanging(bool actionFlag)//フラグ変更を行う関数
    //{
    //    if (move == true)
    //    {
    //        if (actionFlag == true) //キャラが未行動の時true
    //        {
    //            actionFlag = false;

    //        }
    //        else
    //        {
    //            actionFlag = true;
    //        }//フラグは変更できてる。
    //        Debug.Log(actionFlag);
    //    }
    //}



